package com.ecgc.app.service;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class CalculatorServiceTest {

    private CalculatorService service;

    @BeforeClass
    public void setup() {
        service = new CalculatorService();
    }

    @Test
    public void testAdd() {
        Assert.assertEquals(service.add(2, 3), 5);
    }

    @Test
    public void testMultiply() {
        Assert.assertEquals(service.multiply(4, 5), 20);
    }
}
