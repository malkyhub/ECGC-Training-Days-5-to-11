package com.ecgc.app.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class RabbitMQConfiguration {

	public static final String QUEUE_NAME = "com.example.queue";
	public static final String EXCHANGE_NAME = "com.example.exchange";
	public static final String ROUTING_KEY = "com.example.queue";
	
	@Bean
	public Queue myQueue() {
		return new Queue(QUEUE_NAME, true);
	}
	
	@Bean
	public DirectExchange myExchange() {
		return new DirectExchange(EXCHANGE_NAME);
	}
	
	@Bean
	public Binding binding(Queue myQueue, DirectExchange exchange) {
		return BindingBuilder
				.bind(myQueue).to(exchange).with(ROUTING_KEY);
	}
	
	@Bean
	public RabbitAdmin myAdmin(ConnectionFactory connectionFactory) {
		return new RabbitAdmin(connectionFactory);
	}
	
	@Bean
	public RabbitTemplate myTemplate( ConnectionFactory connectionFactory) {
		return new RabbitTemplate(connectionFactory);
	}
	
}
