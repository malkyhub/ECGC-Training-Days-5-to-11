package com.ecgc.app.producer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ecgc.app.config.*;

@Component
public class MessageProducer {

	private static final Logger log= LoggerFactory.getLogger(MessageProducer.class);
	
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	public void sendMessage(String msg) {
		String message =  msg + System.currentTimeMillis();
		log.info("sending Message: '{}'", message);
		
		rabbitTemplate.convertAndSend(RabbitMQConfiguration.EXCHANGE_NAME, RabbitMQConfiguration.ROUTING_KEY, message);
	}
}
