package com.cdac.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.app.client.PostClient;
import com.cdac.app.dto.Post;

@Service
public class PostService {

	@Autowired
	private PostClient postClient;
	
	public Post getPostById(int id) {
		return postClient.getPostById(id);
	}

	public Post addPost(Post post) {
		return postClient.addPost(post);
	}

	public String updatePost(int id, Post post) {
		postClient.updatePost(id, post);
		return "Post Updated successfully!";
	}

	public String deletePost(int id) {
		postClient.deletePost(id);
		return "Post Deleted successfully!";
	}
	
}
