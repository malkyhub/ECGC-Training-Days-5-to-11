package com.cdac.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day10FeignClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
