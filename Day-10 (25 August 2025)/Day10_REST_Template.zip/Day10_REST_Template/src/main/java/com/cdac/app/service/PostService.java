package com.cdac.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cdac.app.dto.Post;

@Service
public class PostService {

	private String url = "https://jsonplaceholder.typicode.com/posts";
	private String localUrl = "http://localhost:8080/users";
	
	@Autowired
	RestTemplate restTemplate;
	
	public Post getPostById(int id) {
//		String url = "https://jsonplaceholder.typicode.com/posts/" + id;
		return restTemplate.getForObject(url + "/" +id, Post.class);
	}

	public Post createPost(Post post) {
		String url = "https://jsonplaceholder.typicode.com/posts";
		return restTemplate.postForObject(url, post, Post.class);
	}

	public String updatePost(int id, Post post) {
		String url = "https://jsonplaceholder.typicode.com/posts/" + id;
		restTemplate.put(url, post);
		return "Post updated successfully!";
	}

	public String deletePost(int id) {
		String url = "https://jsonplaceholder.typicode.com/posts/" + id;
		restTemplate.delete(url);
		return "Post deleted successfully!";
	}

}
