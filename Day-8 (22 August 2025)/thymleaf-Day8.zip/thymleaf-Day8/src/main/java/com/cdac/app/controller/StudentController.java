package com.cdac.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cdac.app.model.Student;
import com.cdac.app.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	StudentService studentService;

	@GetMapping("/student")
	public String studentPage() {
		return "studentPage";
	}
	
	@GetMapping("/studentForm")
	public String StudentForm(Model model) {
		model.addAttribute("student", new Student());
		return "studentForm";
	}
	
	@PostMapping("/studentSave")
	public String addStudent(@ModelAttribute("student") Student student, Model model) {
		studentService.addStudent(student);
		model.addAttribute("student", student);
		return "redirect:/student/listStudents";
	}
	
	@GetMapping("/listStudents")
	public String listStudents(Model model) {
		
		model.addAttribute("students", studentService.getStudents());
		return "studentList";
	}
	
	
	
}
