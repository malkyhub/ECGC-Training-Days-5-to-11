package com.cdac.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.app.model.Student;
import com.cdac.app.repository.StudentRepository;

@Service
public class StudentService {

	
	@Autowired
	StudentRepository studentRepository;
	
	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		
		studentRepository.save(student);
		
	}

	public List<Student> getStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
		
	}

}
