package com.ecgc.app.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.config.JdbcNamespaceHandler;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import com.ecgc.app.dto.Transaction;
import com.ecgc.app.model.BankAccount;

@Repository
public class AccountRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate nmpJdbcTemplate;
	
	@Autowired
	private TransactionTemplate transactionTemplate;
	
	public static final class AccountRowMapper implements RowMapper<BankAccount>{

		@Override
		public BankAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
			BankAccount bankAccount=new BankAccount();
			
			bankAccount.setAccountNo(rs.getInt("AccountNo"));
			bankAccount.setAccountHolderName(rs.getString("AccountHolderName"));
			bankAccount.setAccountBalance(rs.getDouble("AccountBalance"));
			return bankAccount;
		}
		
	}
	
	public int addAccount(String AccountHolderName, double AccountBalance)
	{
		String sql=" INSERT INTO Account (AccountHolderName, AccountBalance) values (:AccountHolderName, :AccountBalance)";
		
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("AccountHolderName", AccountHolderName);
		params.put("AccountBalance", AccountBalance);
		return nmpJdbcTemplate.update(sql, params);

	}
	
	public BankAccount getAccountByNo(int acno) {
		SimpleJdbcCall call=new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("getAccountByNo")
				.returningResultSet("result", new AccountRowMapper());
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("acno", acno);
		
		Map<String, Object> list=call.execute(params);
		
		List<BankAccount> blist=(List<BankAccount>)list.get("result");
		
		return blist.isEmpty()?null:blist.get(0);
		
	}
	
	//Manual Transaction Management
	
	@Transactional
	public void TransferBalance(Transaction transaction) {
		
		//String deduct="UPDATE account SET AccountBalance=AccountBalance -? where AccountNo=?";
		String deduct="update account set accountbalance = accountbalance - ? where accountno = ?";
		jdbcTemplate.update(deduct, transaction.getAmount(), transaction.getSenderAccNo());
		
		if(false)
		{
			throw new RuntimeException("Transaction Failed after deduct");
		}
		
		//String add="UPDATE account SET AccountBalance=AccountBalance +? where AccountNo=?";
		String add="update account set accountbalance = accountbalance + ? where accountno = ?";
		jdbcTemplate.update(add, transaction.getAmount(), transaction.getRecAccNo());
	}
public void transferBalanceUsingTransanctionTemplate(Transaction transaction) {
		
		transactionTemplate.execute(status -> {
            try {
        		String deduct="update bankaccount set accountbalance = accountbalance - ? where accountno = ?";
        		String add="update bankaccount set accountbalance = accountbalance + ? where accountno = ?";
        		jdbcTemplate.update(deduct, transaction.getAmount(), transaction.getSenderAccNo());	
        		jdbcTemplate.update(deduct, transaction.getAmount(), transaction.getRecAccNo());
            } catch (Exception e) {
                status.setRollbackOnly();
            }
            return null;
        });
	}
}