package com.ecgc.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ecgc.app.dto.Transaction;
import com.ecgc.app.model.BankAccount;
import com.ecgc.app.repository.AccountRepository;

@Controller
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	private AccountRepository accountRepository;
	
	@PostMapping("/addaccount")
	@ResponseBody
	public int AddAccount(@RequestBody BankAccount bankAccount) {
		return accountRepository.addAccount(bankAccount.getAccountHolderName(), bankAccount.getAccountBalance());
	}
	
	@GetMapping("/getaccbyno/{acno}")
	@ResponseBody
	public BankAccount GetAccountByNo(@PathVariable int acno)
	{
		return accountRepository.getAccountByNo(acno);
	}
	
	@PostMapping("/transfer")
	@ResponseBody
	public void TransferMoney(@RequestBody Transaction transaction)
	{
		accountRepository.TransferBalance(transaction);
	}
}
