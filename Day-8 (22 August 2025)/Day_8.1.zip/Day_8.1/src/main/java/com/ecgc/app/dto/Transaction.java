package com.ecgc.app.dto;

public class Transaction {

	int SenderAccNo;
	int RecAccNo;
	double Amount;
	
	public Transaction() {
		super();
	}


	public Transaction(int senderAccNo, int recAccNo, double amount) {
		super();
		SenderAccNo = senderAccNo;
		RecAccNo = recAccNo;
		Amount = amount;
	}
	public int getSenderAccNo() {
		return SenderAccNo;
	}


	public void setSenderAccNo(int senderAccNo) {
		SenderAccNo = senderAccNo;
	}


	public int getRecAccNo() {
		return RecAccNo;
	}


	public void setRecAccNo(int recAccNo) {
		RecAccNo = recAccNo;
	}


	public double getAmount() {
		return Amount;
	}


	public void setAmount(double amount) {
		Amount = amount;
	}
}
