package com.ecgc.app.model;

public class BankAccount {
	
	private int AccountNo;
	private String AccountHolderName;
	private double AccountBalance;
	
	public BankAccount() {
		super();
	}
	public BankAccount(int accountNo, String accountHolderName, double accountBalance) {
		super();
		AccountNo = accountNo;
		AccountHolderName = accountHolderName;
		AccountBalance = accountBalance;
	}
	public int getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(int accountNo) {
		AccountNo = accountNo;
	}
	public String getAccountHolderName() {
		return AccountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		AccountHolderName = accountHolderName;
	}
	public double getAccountBalance() {
		return AccountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		AccountBalance = accountBalance;
	}
}
