package com.cdac.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.app.model.Student;
import com.cdac.app.repository.StudentRepository;

@Service
public class StudentService {

	
	@Autowired
	StudentRepository studentRepository;
	
	public void addStudent(Student student) {
		
		if(getStudentById(student.getId()).isPresent()) {
			studentRepository.save(student);
			return;
		}
		studentRepository.save(student);
		
	}

	public List<Student> getStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();	
	}
	
	public Optional<Student> getStudentById(int id) {
		return studentRepository.findById(id);
	}
	
	public void deleteStudent(int id) {
		studentRepository.deleteById(id);
	}

}
