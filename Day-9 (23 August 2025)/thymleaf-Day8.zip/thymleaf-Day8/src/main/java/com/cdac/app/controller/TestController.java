package com.cdac.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/test")
public class TestController {

	@GetMapping("/divide")
	public String divideProblem() {
		
		int a = 10;
		int b = 0;
		
		int result = a/b; // Definitely throw a error.
		
		return "result";
	}
}
