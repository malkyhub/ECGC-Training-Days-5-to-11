package com.cdac.app.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(ArithmeticException.class)
	public String handleArithExp(Model model) {
		model.addAttribute("error", "Cannot be divided by 0. please check the values properly.");
		return "error-page";
	}
	
	
	@ExceptionHandler(NoResourceFoundException.class)
	public String handleNoResExp(Model model) {
		model.addAttribute("error", "There is no resource with mentioned url or path");
		return "error-page";
	}
	
//	@ExceptionHandler(Exception.class)
//	public String handleGlobalExp(Exception ex, Model model) {
//		model.addAttribute("error", ex.getMessage());
//		return "error-page";
//	}
	
}
