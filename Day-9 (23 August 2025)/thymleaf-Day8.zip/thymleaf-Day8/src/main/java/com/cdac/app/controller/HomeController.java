package com.cdac.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.cdac.app.model.Student;

@Controller
public class HomeController {
	@GetMapping("/")
	public String homePage() {
		return "index";
	}
	
	
	@GetMapping("/varExp")
	public String variableExp(Model model) {
		model.addAttribute("name", "shil");
		return "variableExp";
	}
	
	@GetMapping("/selExp")
	public String selectionExp(Model model) {
		model.addAttribute("student", new Student(1, "shil", 20, "shil@cdac.in"));
		return "selectionExp";
	}
	
	@GetMapping("/mesExp")
	public String messageExp() {
		return "messageExp";
	}
	
	@GetMapping("/linkExp")
	public String linkExp() {
		return "linkExp";
	}
	
	@GetMapping("/fragementExp")
	public String fragementExp() {
		return "layout";
	}
}
