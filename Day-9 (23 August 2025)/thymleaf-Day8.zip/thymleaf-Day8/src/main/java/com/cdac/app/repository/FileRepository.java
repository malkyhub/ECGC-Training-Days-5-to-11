package com.cdac.app.repository;

public interface FileRepository {

}
