package com.cdac.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymleafDay9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
