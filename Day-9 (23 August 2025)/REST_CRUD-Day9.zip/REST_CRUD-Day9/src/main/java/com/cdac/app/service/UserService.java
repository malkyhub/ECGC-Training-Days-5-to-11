package com.cdac.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cdac.app.model.User;
import com.cdac.app.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;	
	
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	public Optional<User> getUserById(int id) {
		return userRepository.findById(id);
	}

	public boolean addUser(User user) {
		if(userRepository.save(user) != null)
			return true;
		return false;
	}

	public boolean updateUser(User user) {
		if(getUserById(user.getId()).isPresent()) {
			userRepository.save(user);
			return true;
		}
		return false;
	}

	public boolean deleteUser(int id) {
		if(getUserById(id).isPresent()) {
			userRepository.deleteById(id);
			return true;
		}
		return false;
	}
}
