package com.ecgc.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ecgc.app.model.Student;
import com.ecgc.app.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
//	public StudentController(StudentService studentService) {
//		this.studentService=studentService;
//	}
	
	@GetMapping("/GetAll")
	@ResponseBody
	public List<Student> GetAllStudents()
	{
		return studentService.GetAllStudents();
	}

	@PostMapping("/AddStudent")
	@ResponseBody
	public int AddStudent(@RequestBody Student student)
	{
		return studentService.addStudent(student.getId(), student.getName());
	}
	
	@PostMapping("/deletestudent/{id}")
	@ResponseBody
	public int DeleteStudent(@PathVariable int id)
	{
		return studentService.deleteStudent(id);
	}
	
	@PostMapping("/updatestudent/{id}")
	@ResponseBody
	public int UpdateStudent(@PathVariable int id, @RequestBody Student student)
	{
		return studentService.updateStudent(id, student);
	}
}
