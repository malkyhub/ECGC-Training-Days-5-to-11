package com.ecgc.app.repository;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.stereotype.Repository;

import com.ecgc.app.model.Student;

@Repository
public interface StudentRepository {

	@Query()
	public int addStudent(Student student);
	public List<Student> getByName(String name);
}
