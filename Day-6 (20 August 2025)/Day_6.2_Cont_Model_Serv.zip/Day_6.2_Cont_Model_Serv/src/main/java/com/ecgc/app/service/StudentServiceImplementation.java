package com.ecgc.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ecgc.app.model.Student;

@Service
public class StudentServiceImplementation implements StudentService {

	
	private List<Student> students=new ArrayList<Student>();
	
	@Override
	public int addStudent(int id, String name) {
		boolean flag=students.add(new Student(id,name));
		if(flag==true)
		{
			return 1;
		}
		return 0;
	}

	@Override
	public int deleteStudent(int id) {
		int index;
		boolean flag=false;
		for(Student s:students)
		{
			if(s.getId()==id)
			{
				index=students.indexOf(s);
				students.remove(index);
				flag=true;
				break;
			}
		}
		
		return 1;
	}

	@Override
	public List<Student> GetAllStudents() {
		
		return students;
	}

	@Override
	public int updateStudent(int id, Student student) {
		
		for(Student s:students)
		{
			if(s.getId()==id)
			{
				s.setName(student.getName());
				break;
			}
		}
		
		return 1;
	}

}
