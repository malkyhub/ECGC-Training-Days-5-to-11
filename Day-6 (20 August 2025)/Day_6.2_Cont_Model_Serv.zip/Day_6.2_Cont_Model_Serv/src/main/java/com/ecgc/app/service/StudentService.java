package com.ecgc.app.service;

import java.util.List;

import com.ecgc.app.model.Student;

public interface StudentService {

	public int addStudent(int id, String name);
	
	public int deleteStudent(int id);
	public List<Student> GetAllStudents();
	public int updateStudent(int id, Student student);
}
