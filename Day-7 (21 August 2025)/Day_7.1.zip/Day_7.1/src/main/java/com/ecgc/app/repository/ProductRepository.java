package com.ecgc.app.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ecgc.app.model.Product;

@Repository
public class ProductRepository {
	
	
	public static final class ProductResultSetExtracter implements ResultSetExtractor<List<Product>>{

		@Override
		public List<Product> extractData(ResultSet rs) throws SQLException, DataAccessException {
			List<Product> list=new ArrayList<Product>();
			
			while(rs.next())
			{
				Product product=new Product();
				product.setId(rs.getInt("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				list.add(product);
			}
			return list;
		}
		
	}
	
	public static final class ProductRowMapper implements RowMapper<Product>{

		@Override
		public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
			Product product=new Product();
			while(rs.next())
			{
				product.setId(rs.getInt("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
			}
			return product;
		}
		
	}
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void createProductTable()
	{
		jdbcTemplate.update("Create table student1 (id INT PRIMARY KEY AUTO_INCREMENT, name varchar(50))");
	}
	
	
	public int addStudent(String name)
	{
		String sql="Insert into student1 (name) values (?)";
		
		return jdbcTemplate.update(sql, name);
	}
	
	public int addProduct(Product product)
	{
		String sql=" Insert into product (name, price) values (?, ?)";
		return jdbcTemplate.update(sql, product.getName(), product.getPrice());
	}
	
	public List<Product> getAllProducts()
	{
		String sql="Select * from product";
		return jdbcTemplate.query(sql, new ProductResultSetExtracter());
	}
	
	public Product getProductById(int id)
	{
		String sql="Select * from product where id=?";
		List<Product> list=jdbcTemplate.query(sql, new ProductRowMapper(), id);
		return list.get(0);
	}
	
	public int deleteProduct(int id)
	{
		String sql="delete from product where id =?";
		return jdbcTemplate.update(sql, id);
	}
	
	public int updateProduct(int id, Product product)
	{
		String sql="update product set name=?, price=? where id=?";
		return jdbcTemplate.update(sql, product.getName(), product.getPrice(), id);
	}
}
