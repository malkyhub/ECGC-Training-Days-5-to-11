package com.ecgc.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ecgc.app.model.Product;
import com.ecgc.app.model.Student1;
import com.ecgc.app.repository.ProductRepository;

@Controller
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductRepository productRepository;
	
	
	@GetMapping("/getallproducts")
	@ResponseBody
	public List<Product> GetAllProducts()
	{
		return productRepository.getAllProducts();
	}
	
	@PostMapping("/addproduct")
	@ResponseBody
	public int AddProduct(@RequestBody Product product)
	{
		return productRepository.addProduct(product);
	}
	
	@GetMapping("/getproductbyid/{id}")
	@ResponseBody
	public Product GetProductById(@PathVariable int id)
	{
		return productRepository.getProductById(id);
	}
	
	@PostMapping("/deleteproduct/{id}")
	@ResponseBody
	public int DeleteProduct(@PathVariable int id)
	{
		return productRepository.deleteProduct(id);
	}
	
	@PostMapping("/updateproduct/{id}")
	@ResponseBody
	public int UpdateProduct(@PathVariable int id, @RequestBody Product product)
	{
		return productRepository.updateProduct(id, product);
	}
	
	
	
	@GetMapping("/createtable")
	public void CreateTable()
	{
		productRepository.createProductTable();
	}
	
	
	
	@PostMapping("/addstudent1")
	public int AddStudent(@RequestBody Student1 student1)
	{
		return productRepository.addStudent(student1.getName());
	}

}
